<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['site_name'] = 'IGLI';

date_default_timezone_set("Asia/Kolkata");