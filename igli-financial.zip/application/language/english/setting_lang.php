<?php

/* Common */
$lang['site_name'] = 'Site Name';
$lang['site_title'] = 'Site Title';
$lang['favicon'] = 'Favicon';
$lang['logo'] = 'Logo';